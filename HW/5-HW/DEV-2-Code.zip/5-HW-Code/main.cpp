
//Main file for my Blackjack game
#include <iostream>
#include <vector>
#include <chrono>
#include <random>
#include <algorithm>
#include "Player.hpp"
#include "Card.hpp"
#include "Joker.hpp"
#include "Emperor.hpp"
#include "Dealer.hpp"
using std::vector;
using std::cout;
using std::cin;
using std::endl;
/*
    
Deliverable 1 
•	Create players
•	Create cards
•	X number players
•	Create CLI interface for asking basic questions
o	Will be able to ADD players by name up to chosen number
o	Will Deal cards telling people what they got 
o	No betting at this point
•	Will operate as a traditional Blackjack table	



*/
std::vector<Player*> addPlayers() {
    std::vector<Player*> players;
    int playerCount = 0;
    std::string playerName;
    while(playerCount < 8){
        std::cout << "Enter player name: ";
        getline(std::cin, playerName);

        // If the player enters "done" or inputs ENTER then stop asking for names
        if(playerName == "done" || playerName == ""){
            break;
        }
        // Create a new Player and add them to the players vector
        Player* newPlayer = new Player(playerName); // Note the usage of 'new' here.
        players.push_back(newPlayer);
        playerCount++;
    }
    // Optional: show how many players were created
    std::cout << "Total players: " << playerCount << std::endl;

    return players;
}

vector<Card*> createDeck() {
    vector<Card*> deck;
    for (int suit = 0; suit < static_cast<int>(Suit::MAX_SUITS); ++suit) {
        for (int rank = 0; rank < static_cast<int>(Rank::MAX_RANKS); ++rank) {
            
            deck.push_back(new Card(static_cast<Suit>(suit), static_cast<Rank>(rank), true));
        }
    }
    cout<<"Deck created"<<endl;
    return deck;
}
void AddSpecialCards(std::vector<Card*> *deck, int player_count) {
    // Add Joker cards
    // Add Emperor cards

    

    for (int i = 1; i < player_count; i++) {
        // Create and add Joker cards
        // Initialize the joker card with a value of 0 since the player will set the value
        deck->push_back(new Joker(0, Suit::SUIT_CLUB, Rank::RANK_ACE, true));
        cout<<"Joker added"<<endl;
    }

    // Create and add Emperor cards
    for(int i = 1; i < player_count; i++) {
        // Initialize the emperor card with a value of 0 since the player will set the value
        deck->push_back(new Emperor(0, Suit::SUIT_CLUB, Rank::RANK_ACE, true));
        cout<<"Emperor added"<<endl;
    }
}


void shuffleDeck(vector<Card*> &deck) {
    // Obtain a time-based seed:
    unsigned seed = std::chrono::system_clock::now().time_since_epoch().count();

    // Shuffle the deck
    std::shuffle(deck.begin(), deck.end(), std::default_random_engine(seed));

    cout << "Deck shuffled" << endl;
}

void dealCards(vector<Card*> &deck, vector<Player*> &players) {
    // Deal 2 cards to each player
    for (int i = 0; i < 2; i++) {
        for (auto player : players) {
            player->addCard(deck.back());
            deck.pop_back();
        }
    }

    // Deal 2 cards to the dealer
    players.push_back(new Player("Dealer"));
    for (int i = 0; i < 2; i++) {
        players.back()->addCard(deck.back());
        deck.pop_back();
    }

    cout << "Cards dealt" << endl;
}


void playerTurn(vector<Card*> &deck, vector<Player*> &players) {
    // Player's turn
    for (auto player : players) {
        if (player->getName() == "Dealer") {
            continue;
        }

        cout << player->getName() << "'s turn" << endl;
        cout << "Your hand: ";
        player->printHand();
        cout << "Your hand value: " << player->GetHandValue() << endl;

        // Ask the player if they want to hit or stand
        char choice;
        do {
            cout << "Do you want to hit or stand? (h/s): ";
            cin >> choice;
            if (choice == 'h') {
                player->addCard(deck.back());
                deck.pop_back();
                cout << "Your hand: ";
                player->printHand();
                cout << "Your hand value: " << player->GetHandValue() << endl;
            }
        } while (choice == 'h' && !player->IsBusted());
    }
}


//Playing the game with the deck and Playuers
//input of the deck and players
void PlayBlackjack(vector<Card*> &deck, vector<Player*> &players) {
    // Deal the cards
    dealCards(deck, players);

    // Player's turn
    playerTurn(deck, players);

    // Dealer's turn
    // dealerTurn(deck, players);

    // Print the results
    // PrintResults(true);
}
int main()
{
    //Task 1: Create a deck of cards
    std::vector<Card*> deck = createDeck();
    //Task 2: Add players to the game
    vector<Player*> players_ = addPlayers();

    //Adding the dealer
    players_.push_back(new Dealer("Dealer"));
    //Task 3: Add special cards to the deck
    AddSpecialCards(&deck, players_.size());

    shuffleDeck(deck);
    // //Task 4:    
    // //Task 5: Play the game
    PlayBlackjack(deck, players_);;
    // //Task 6: Print the results
    // PrintResults(true);
    // //Task 7: End the game
    // endGame();
    for (auto player : players_) {
        delete player;
    }
    return 0;
}
//functions to be implemented




void PrintResults(bool playerWins);
void dealCards();
void playerTurn();
void dealerTurn();
void endGame();
void printHand();
void printDealerHand();



