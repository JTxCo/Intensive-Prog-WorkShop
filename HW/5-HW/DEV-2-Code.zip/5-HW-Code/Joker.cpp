#ifndef JOKER_CPP
#define JOKER_CPP
#include "Joker.hpp"

Joker::Joker(int value, Suit suit, Rank rank, bool isFaceUp)
    : Card(suit, rank, isFaceUp)
{
    m_value = value;    
}

#endif /* JOKER_CPP */