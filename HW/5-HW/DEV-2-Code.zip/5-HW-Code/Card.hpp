#ifndef CARD_HPP
#define CARD_HPP

#include <iostream>

enum class Suit
{
    SUIT_CLUB,
    SUIT_DIAMOND,
    SUIT_HEART,
    SUIT_SPADE,
    MAX_SUITS
};

enum class Rank
{
    RANK_2,
    RANK_3,
    RANK_4,
    RANK_5,
    RANK_6,
    RANK_7,
    RANK_8,
    RANK_9,
    RANK_10,
    RANK_JACK,
    RANK_QUEEN,
    RANK_KING,
    RANK_ACE,
    MAX_RANKS
};

class Card
{
    private:
        Suit m_suit;
        Rank m_rank;
        bool m_isFaceUp;
    public:
        Card(Suit suit, Rank rank, bool isFaceUp);  // Add this constructor
        void Flip();
        int GetValue() const;
        friend std::ostream& operator<<(std::ostream& out, const Card& card);
};

#endif // CARD_HPP
