// Emperor.hpp
#ifndef EMPEROR_HPP
#define EMPEROR_HPP

#include "Card.hpp"

class Emperor : public Card {
private:
    int m_value;
public:
    Emperor(int value, Suit suit, Rank rank, bool isFaceUp);
    int getValue();
    void setValue(int value);
    friend std::ostream& operator<< (std::ostream& out, const Emperor& emperor);
};

#endif /* EMPEROR_HPP */
