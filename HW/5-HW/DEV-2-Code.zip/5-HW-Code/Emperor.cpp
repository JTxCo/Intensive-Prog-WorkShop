// Emperor.cpp
#include "Emperor.hpp"

Emperor::Emperor(int value, Suit suit, Rank rank, bool isFaceUp) : Card(suit, rank, isFaceUp), m_value(value) {}

int Emperor::getValue(){
    return m_value;
}

void Emperor::setValue(int value){
    m_value = value;
}

// Fill in operator<< function.
