#include "Card.hpp"

Card::Card(Suit suit, Rank rank, bool isFaceUp)
    : m_suit(suit), m_rank(rank), m_isFaceUp(isFaceUp)
{
    // Your code here
}

void Card::Flip()
{
    m_isFaceUp = !m_isFaceUp;
}

int Card::GetValue() const
{
    int value{ 0 };
    if (m_isFaceUp)
    {
        switch(m_rank) 
        {
            case Rank::RANK_10:
            case Rank::RANK_JACK:
            case Rank::RANK_QUEEN:
            case Rank::RANK_KING:
                value = 10;
                break;
            default:
                value = static_cast<int>(m_rank) + 2;  // Adding 2 because the Rank enum starts at 0 for RANK_2
        }
    }
    return value;
}

// friend std::ostream& operator<<(std::ostream& out, const Card& card)

std::ostream& operator<<(std::ostream& out, const Card& card)
{
    // if (card.m_isFaceUp)
    // {
        const char* suit{};
        const char* rank{};

        switch (card.m_suit)
        {
        case Suit::SUIT_CLUB:
            suit = "C";
            break;
        case Suit::SUIT_DIAMOND:
            suit = "D";
            break;
        case Suit::SUIT_HEART:
            suit = "H";
            break;
        case Suit::SUIT_SPADE:
            suit = "S";
            break;
        case Suit::MAX_SUITS:
            suit = "Invalid Suit";
            break;
        }

        switch (card.m_rank)
        {
        case Rank::RANK_2:
            rank = "2";
            break;
        case Rank::RANK_3:
            rank = "3";
            break;
        case Rank::RANK_4:
            rank = "4";
            break;
        case Rank::RANK_5:
            rank = "5";
            break;
        case Rank::RANK_6:
            rank = "6";
            break;
        case Rank::RANK_7:
            rank = "7";
            break;
        case Rank::RANK_8:
            rank = "8";
            break;
        case Rank::RANK_9:
            rank = "9";
            break;
        case Rank::RANK_10:
            rank = "10";
            break;
        case Rank::RANK_JACK:
            rank = "J";
            break;
        case Rank::RANK_QUEEN:
            rank = "Q";
            break;
        case Rank::RANK_KING:
            rank = "K";
            break;
        case Rank::RANK_ACE:
            rank = "A";
            break;
        case Rank::MAX_RANKS:
            rank = "Invalid Rank";
            break;
        }

        out << rank << suit;
    // }
    // else
    // {
    //     out << "XX";
    // }

    return out;
}