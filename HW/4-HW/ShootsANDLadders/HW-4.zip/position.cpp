#include "position.h"

// Position::Position(int x, int y, Position* shootOrLadderEnd):
