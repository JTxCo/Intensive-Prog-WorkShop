#include "benchmark/benchmark.h"
/*
    * This file is used to run the benchmark the functions in the project.
    *I included insertion and search benchmarks
    * The benchmarks are run using the google benchmark library
    * The library is required to be installed in order to run it.
    * The library can be installed by following the link to the instructions in th github on the readme
    *I have included the results from the benchmarks for ease of viewing:

    

*/
BENCHMARK_MAIN();